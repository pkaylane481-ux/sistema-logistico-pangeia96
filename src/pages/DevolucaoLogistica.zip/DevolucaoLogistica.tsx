import {useMemo, useState } from "react";

import { useSistema } from "../context/SistemaContext";

import FiltroRegistros from "../components/FiltroRegistros";

import ExportarExcel from "../components/ExportarExcel";

import ResultadoDevolucao from "../components/dashboard/ResultadoDevolucao";

import DevolucaoLogisticaResumo from "../components/dashboard/DevolucaoLogisticaResumo";

import DevolucaoAnaliseResultado from "../components/dashboard/DevolucaoAnaliseResultado";

import DevolucaoDestinoChart from "../components/dashboard/DevolucaoDestinoChart";

import DevolucaoMotivosChart from "../components/dashboard/DevolucaoMotivosChart";

import DevolucaoTransportadorasChart from "../components/dashboard/DevolucaoTransportadorasChart";

import DevolucaoCasosCriticos from "../components/dashboard/DevolucaoCasosCriticos";

import {
  adicionarHistoricoDevolucaoLogistica,
  buscarHistoricoDevolucaoLogistica
} from "../services/historicoDevolucoesLogistica";



export default function DevolucaoLogistica(){



const {
  devolucoesLogistica,
  carregarDados,
  adicionarDevolucao,
  removerDevolucao,
  historicosDevolucao,
  carregarHistoricoDevolucao,
  registrarHistoricoDevolucao,
  atualizarDevolucao,
  operadores,
  transportadoras,
  motivos
} = useSistema();







// ============================
// CARREGAR SUPABASE
// ============================









// ============================
// FILTRO
// ============================


const [listaFiltrada,setListaFiltrada]=

useState<any[]>([]);


const [abaAtiva, setAbaAtiva] =
useState<"formulario" | "dashboard">("formulario");




// ============================
// FORMULÁRIO
// ============================



const [data,setData]=useState("");

const [pedido,setPedido]=useState("");

const [cliente,setCliente]=useState("");

const [transportadora,setTransportadora]=useState("");

const [motivo,setMotivo]=useState("");

const [status,setStatus]=useState("Recebido");

const [responsavel,setResponsavel]=useState("");

const [observacao,setObservacao]=useState("");

const [devolucaoSelecionada, setDevolucaoSelecionada] =
useState<DevolucaoLogistica | null>(null);



const [salvando, setSalvando] =
useState(false);


// ============================
// EDIÇÃO
// ============================

const [editando, setEditando] =
useState(false);

const [somenteLeitura, setSomenteLeitura] =
useState(false);

const [registroSelecionado, setRegistroSelecionado] =
useState<any>(null);

const [editStatus, setEditStatus] =
useState("");

const [editObservacao, setEditObservacao] =
useState("");

const [editContatos, setEditContatos] =
useState(0);

const [editDecisaoFinal, setEditDecisaoFinal] =
useState("");



// ============================
// REENVIO
// ============================


const [precisaReenvio,setPrecisaReenvio]=useState("Não");

const [novoPedido,setNovoPedido]=useState("");

const [dataReenvio,setDataReenvio]=useState("");











// ============================
// ESTILOS
// ============================


const inputStyle={

padding:"10px",

border:"1px solid #ddd",

borderRadius:"8px",

width:"100%"

};





const cardStyle={

background:"#fff",

padding:"20px",

borderRadius:"12px",

boxShadow:"0 3px 10px rgba(0,0,0,.08)",

display:"flex",

flexDirection:"column" as const,

gap:"12px"

};






const buttonStyle={

padding:"12px 20px",

background:"#7c3aed",

color:"#fff",

border:"none",

borderRadius:"10px",

cursor:"pointer",

fontWeight:"bold" as const

};









// ============================
// SALVAR DEVOLUÇÃO
// ============================


async function salvarDevolucao(){



if(!pedido || !cliente){


alert(

"Informe pedido e cliente."

);


return;


}






await adicionarDevolucao({
  data,
  pedido,
  cliente,
  transportadora,
  motivo,
  status,
  responsavel,
  observacao,
  destino: precisaReenvio === "Sim" ? "Reenvio" : "Estoque"
});







setData("");

setPedido("");

setCliente("");

setTransportadora("");

setMotivo("");

setStatus("Recebido");

setResponsavel("");

setObservacao("");

setPrecisaReenvio("Não");

setNovoPedido("");

setDataReenvio("");



}

function calcularDecisaoFinal(item:any){

  switch(item.status){

    case "Recebido":
      return "Em andamento";

    case "Em contato":
      return "Aguardando retorno";

    case "Reenviar":
      return "Reenvio aprovado";

    case "Enviado":
      return "Finalizado";

    case "Cancelado":
      return "Cancelado";

    case "Para estoque":
      return "Aguardando estoque";

    case "Estoque":
      return "Finalizado";

    default:
      return "";

  }

}

// ============================
// ABRIR DEVOLUÇÃO
// ============================

async function abrirDevolucao(item:any){

  setRegistroSelecionado(item);

  setEditStatus(item.status ?? "");

  setEditObservacao(item.observacao ?? "");

  setEditContatos(item.contatos ?? 0);

  setEditDecisaoFinal(item.decisao_final ?? "");
  const bloqueado = [
    "Enviado",
    "Cancelado",
    "Estoque"
].includes(item.status);

setSomenteLeitura(bloqueado);


  await carregarHistoricoDevolucao(item.id);

setEditando(true);

}
// ============================
// ABRIR EDIÇÃO
// ============================

async function registrarContato(){


if(!registroSelecionado){
  return;
}


const novoContador =
(registroSelecionado.contatos || 0) + 1;



const atualizado = {

...registroSelecionado,

contatos: novoContador

};



setRegistroSelecionado(atualizado);
setEditContatos(novoContador);


await atualizarDevolucao(

registroSelecionado.id,

{

contatos: novoContador

}

);

console.log("ID da devolução:", registroSelecionado.id);
console.log("Status:", editStatus);

await registrarHistoricoDevolucao({

  devolucao_id: registroSelecionado.id,

  acao: "Contato realizado",

descricao:
  `${novoContador}ª tentativa de contato registrada.`,

  usuario: "Sistema"

});



await carregarHistoricoDevolucao(

registroSelecionado.id

);


}

async function abrirEdicao(item:any){

  setRegistroSelecionado(item);

  setEditStatus(item.status ?? "");

  setEditObservacao(item.observacao ?? "");

  setEditContatos(
    item.quantidade_contatos ?? 0
  );

  setEditDecisaoFinal(
    item.decisao_final ?? ""
  );

  const bloqueado = [

  "Enviado",
  "Cancelado",
  "Estoque"

].includes(item.status);

setSomenteLeitura(bloqueado);

 await carregarHistoricoDevolucao(item.id);

setEditando(true);

}

async function salvarEdicao(){

  if(somenteLeitura){

  return;

}


if(!registroSelecionado){
  return;
}



setSalvando(true);



try{

  const statusAnterior = registroSelecionado.status;
const observacaoAnterior = registroSelecionado.observacao ?? "";
const decisaoAnterior = registroSelecionado.decisao_final ?? "";

const dadosAtualizados = {


status: editStatus,


observacao: editObservacao,


contatos: editContatos,


decisao_final: editDecisaoFinal


};





await atualizarDevolucao(

registroSelecionado.id,

dadosAtualizados

);

const finalizado = [

  "Enviado",

  "Cancelado",

  "Estoque"

].includes(editStatus);

setSomenteLeitura(finalizado);
await carregarDados();



if(statusAnterior !== editStatus){

  await registrarHistoricoDevolucao({

    devolucao_id: registroSelecionado.id,

    acao: "Status",

    descricao: `${statusAnterior} → ${editStatus}`,

    usuario: "Sistema"

  });

}

if(observacaoAnterior !== editObservacao){

  await registrarHistoricoDevolucao({

    devolucao_id: registroSelecionado.id,

    acao: "Observação",

    descricao: "Observação alterada.",

    usuario: "Sistema"

  });

}

if(decisaoAnterior !== editDecisaoFinal){

  await registrarHistoricoDevolucao({

    devolucao_id: registroSelecionado.id,

    acao: "Decisão Final",

    descricao: `Alterada para ${editDecisaoFinal}`,

    usuario: "Sistema"

  });

}
await carregarHistoricoDevolucao(registroSelecionado.id);


await carregarDados();






}

catch(error){


console.error(

"Erro ao salvar alteração:",

error

);


alert(

"Erro ao salvar alterações."

);


}

finally{


setSalvando(false);


}


}

function fecharEdicao(){

  setEditando(false);

  setRegistroSelecionado(null);

}

function corContato() {

  if (editContatos === 1) {
    return "#22c55e";
  }

  if (editContatos === 2) {
    return "#eab308";
  }

  if (editContatos >= 3) {
    return "#dc2626";
  }

  return "#6b7280";

}

function atualizarDecisaoFinal(

  status:string

){

  if(status==="Estoque"){

    setEditDecisaoFinal("Estornado");

    return;

  }

  if(status==="Enviado"){

    setEditDecisaoFinal("Reenviado");

    return;

  }

  setEditDecisaoFinal("");

}

function alterarStatus(novoStatus: string) {

  let decisao = "";

  switch (novoStatus) {

    case "Recebido":
      decisao = "Em andamento";
      break;

    case "Em contato":
      decisao = "Aguardando retorno";
      break;

    case "Reenviar":
      decisao = "Reenvio aprovado";
      break;

    case "Enviado":
      decisao = "Reenviado";
      break;

    case "Para estoque":
      decisao = "Aguardando estoque";
      break;

    case "Estoque":
      decisao = "Estornado";
      break;

    case "Cancelado":
      decisao = "Cancelado";
      break;

    default:
      decisao = "";

  }

  setEditStatus(novoStatus);

  setEditDecisaoFinal(decisao);

  setRegistroSelecionado({

    ...registroSelecionado,

    status: novoStatus,

    decisao_final: decisao

  });

}



// ============================
// REGISTROS
// ============================

const registros = useMemo(()=>{

return devolucoesLogistica || [];

},[
devolucoesLogistica
]);




const registrosExibidos =

listaFiltrada.length > 0

?

listaFiltrada

:

registros;


const devolucoesDashboard = useMemo(()=>{

return registrosExibidos;

},[
registrosExibidos
]);

const indicadoresDashboard = useMemo(()=>{

const dados = devolucoesDashboard || [];


return {

total: dados.length,


pendentes:
dados.filter(item =>
[
"Recebido",
"Em análise",
"Aguardando cliente"
].includes(item.status)
).length,


reenvios:
dados.filter(item =>
item.destino === "Reenvio"
).length,


estoque:
dados.filter(item =>
item.destino === "Estoque"
).length,


status: {

Recebido:
dados.filter(item=>item.status==="Recebido").length,

"Em análise":
dados.filter(item=>item.status==="Em análise").length,

"Aguardando cliente":
dados.filter(item=>item.status==="Aguardando cliente").length,

Finalizado:
dados.filter(item=>item.status==="Finalizado").length

},


motivos:
dados.reduce((acc:any,item)=>{

const nome=item.motivo || "Sem motivo";

acc[nome]=(acc[nome]||0)+1;

return acc;

},{}),


transportadoras:
dados.reduce((acc:any,item)=>{

const nome=item.transportadora || "Sem transportadora";

acc[nome]=(acc[nome]||0)+1;

return acc;

},{})

}


},[
devolucoesDashboard
]);

const statusResumo = useMemo(()=>{

return [

{
nome:"Recebido",
valor: devolucoesDashboard.filter(
item=>item.status==="Recebido"
).length
},

{
nome:"Em contato",
valor: devolucoesDashboard.filter(
item=>item.status==="Em contato"
).length
},

{
nome:"Reenviar",
valor: devolucoesDashboard.filter(
item=>item.status==="Reenviar"
).length
},

{
nome:"Enviado",
valor: devolucoesDashboard.filter(
item=>item.status==="Enviado"
).length
},

{
nome:"Estoque",
valor: devolucoesDashboard.filter(
item=>item.status==="Estoque"
).length
}

];

},[
devolucoesDashboard
]);

// ============================
// EXPORTAÇÃO
// ============================



const colunasExportacao=[



{
campo:"dataEntrada",
titulo:"Data"
},



{
campo:"pedido",
titulo:"Pedido"
},



{
campo:"cliente",
titulo:"Cliente"
},



{
campo:"transportadora",
titulo:"Transportadora"
},



{
campo:"motivo",
titulo:"Motivo"
},



{
campo:"status",
titulo:"Status"
},



{
campo:"responsavel",
titulo:"Responsável"
},



{
campo:"precisaReenvio",
titulo:"Reenvio"
},



{
campo:"novoPedido",
titulo:"Novo Pedido"
},



{
campo:"observacao",
titulo:"Observação"
}



];









return (


<div className="p-6">






{/* ============================
        CABEÇALHO
============================ */}


<div

className="
w-full
bg-gradient-to-r
from-purple-900
to-purple-800
rounded-2xl
px-6
py-5
mb-6
flex
items-center
justify-between
shadow-sm
"

>

<div>

<h1

className="
text-2xl
font-bold
text-white
"

>

Devoluções Logísticas

</h1>


<p

className="
text-purple-200
text-sm
mt-1
"

>

Controle de retornos, reenvios e tratativas operacionais

</p>


</div>



<ExportarExcel


dados={registrosExibidos}


nomeArquivo="devolucao_logistica"


nomeAba="Devoluções"


titulo="Exportar Excel"


colunas={colunasExportacao}


/>


</div>

{/* ================================
        FILTROS
================================= */}

<FiltroRegistros

registros={devolucoesLogistica}

operadores={operadores}

atividades={[]}

transportadoras={transportadoras}

motivos={motivos}

onFiltrar={(dados)=>{

setListaFiltrada(dados);

}}

/>



{/* ==========================
        ABAS
========================== */}

<div
style={{
display:"flex",
gap:"12px",
marginTop:"20px",
marginBottom:"20px"
}}
>

<button
onClick={()=>setAbaAtiva("formulario")}
style={{
padding:"12px 25px",
borderRadius:"10px",
border:"none",
cursor:"pointer",
fontWeight:"bold",
background:
abaAtiva==="formulario"
?
"#7c3aed"
:
"#e5e7eb",
color:
abaAtiva==="formulario"
?
"#fff"
:
"#333"
}}
>
➕ Registrar Devolução
</button>


<button
onClick={()=>setAbaAtiva("dashboard")}
style={{
padding:"12px 25px",
borderRadius:"10px",
border:"none",
cursor:"pointer",
fontWeight:"bold",
background:
abaAtiva==="dashboard"
?
"#7c3aed"
:
"#e5e7eb",
color:
abaAtiva==="dashboard"
?
"#fff"
:
"#333"
}}
>
📊 Dashboard
</button>

</div>

{/* ================================
      MINI DASH DEVOLUÇÃO LOGÍSTICA
================================= */}
{
abaAtiva==="dashboard" && (

<>

<div
  style={{
    display: "flex",
    flexDirection: "column",
    gap: "24px",
    marginTop: "20px"
  }}
>

{/* =======================================================
   LINHA 1 - KPIs EXECUTIVOS
======================================================= */}

<div
style={{
display:"grid",
gridTemplateColumns:"repeat(6,1fr)",
gap:"18px",
marginBottom:"25px"
}}
>

{[
{
titulo:"Total",
icone:"📦",
valor:devolucoesDashboard.length,
cor:"#2563eb"
},
{
titulo:"Pendentes",
icone:"🟡",
valor:devolucoesDashboard.filter(x=>
["Recebido","Em contato","Reenviar","Para estoque"].includes(x.status)
).length,
cor:"#f59e0b"
},
{
titulo:"Em Contato",
icone:"📞",
valor:devolucoesDashboard.filter(x=>
x.status==="Em contato"
).length,
cor:"#8b5cf6"
},
{
titulo:"Reenvios",
icone:"🚚",
valor:devolucoesDashboard.filter(x=>
x.destino==="Reenvio"
).length,
cor:"#0ea5e9"
},
{
titulo:"Estoque",
icone:"📦",
valor:devolucoesDashboard.filter(x=>
x.status==="Estoque"
).length,
cor:"#10b981"
},
{
titulo:"Finalizados",
icone:"✅",
valor:devolucoesDashboard.filter(x=>
["Enviado","Cancelado","Estoque"].includes(x.status)
).length,
cor:"#22c55e"
}

].map(card=>(

<div
key={card.titulo}
style={{
background:"#fff",
borderRadius:"18px",
padding:"20px",
boxShadow:"0 6px 18px rgba(0,0,0,.08)",
borderTop:`6px solid ${card.cor}`
}}
>

<div
style={{
display:"flex",
justifyContent:"space-between",
alignItems:"center"
}}
>

<div>

<div
style={{
fontSize:"15px",
color:"#666",
fontWeight:600
}}
>
{card.titulo}
</div>

<div
style={{
fontSize:"38px",
fontWeight:"bold",
marginTop:"8px",
color:card.cor
}}
>
{card.valor}
</div>

</div>

<div
style={{
fontSize:"42px"
}}
>
{card.icone}
</div>

</div>

</div>

))}

</div>

{/* =======================================================
   LINHA 2
======================================================= */}

<div
style={{
display:"grid",
gridTemplateColumns:"1fr 1fr",
gap:"22px",
marginBottom:"25px"
}}
>

{/* MOTIVOS */}

<div
style={{
background:"#fff",
borderRadius:"18px",
padding:"22px",
boxShadow:"0 6px 18px rgba(0,0,0,.08)"
}}
>

<h3
style={{
marginBottom:"25px",
fontSize:"20px",
fontWeight:"bold"
}}
>
Motivos das Devoluções
</h3>

{(() => {

const dados = Object.entries(

devolucoesDashboard.reduce((acc:any,item:any)=>{

const nome=item.motivo || "Não informado";

acc[nome]=(acc[nome]||0)+1;

return acc;

},{})

)

.sort((a:any,b:any)=>b[1]-a[1])

.slice(0,6);

const maior = Math.max(...dados.map((d:any)=>d[1]),1);

return(

<div
style={{
display:"flex",
alignItems:"flex-end",
justifyContent:"space-between",
height:"280px",
gap:"16px"
}}
>

{dados.map(([nome,total]:any)=>(

<div
key={nome}
style={{
flex:1,
display:"flex",
flexDirection:"column",
alignItems:"center",
justifyContent:"flex-end"
}}
>

<div
style={{
fontWeight:"bold",
marginBottom:"8px",
color:"#444"
}}
>
{total}
</div>

<div
style={{
width:"100%",
height:`${(total/maior)*180+20}px`,
background:"linear-gradient(to top,#7c3aed,#a855f7)",
borderRadius:"12px 12px 0 0",
transition:"0.4s"
}}
/>

<div
style={{
marginTop:"12px",
fontSize:"12px",
textAlign:"center",
fontWeight:500,
color:"#666"
}}
>
{nome}
</div>

</div>

))}

</div>

);

})()}

</div>

{/* TRANSPORTADORAS */}

<div
style={{
background:"#fff",
borderRadius:"18px",
padding:"22px",
boxShadow:"0 6px 18px rgba(0,0,0,.08)"
}}
>

<h3
style={{
marginBottom:"20px",
fontSize:"20px",
fontWeight:"bold"
}}
>
Transportadoras
</h3>

{(() => {

const dados = Object.entries(

devolucoesDashboard.reduce((acc:any,item:any)=>{

const nome = item.transportadora || "Sem informação";

acc[nome] = (acc[nome] || 0) + 1;

return acc;

},{})

)

.sort((a:any,b:any)=>b[1]-a[1])

.slice(0,6);

const maior = Math.max(...dados.map((x:any)=>x[1]),1);

return (

<div>

<svg
width="100%"
height="260"
viewBox="0 0 600 260"
>

{/* eixo */}

<line
x1="40"
y1="220"
x2="570"
y2="220"
stroke="#ddd"
/>

<line
x1="40"
y1="20"
x2="40"
y2="220"
stroke="#ddd"
/>

{/* linha */}

<polyline
fill="none"
stroke="#2563eb"
strokeWidth="4"
points={
dados.map((item:any,index)=>{

const x=60+(index*95);

const y=220-((item[1]/maior)*170);

return `${x},${y}`;

}).join(" ")
}
/>

{/* pontos */}

{

dados.map((item:any,index)=>{

const x=60+(index*95);

const y=220-((item[1]/maior)*170);

return(

<g key={index}>

<circle
cx={x}
cy={y}
r="6"
fill="#2563eb"
/>

<text
x={x}
y={y-12}
fontSize="13"
textAnchor="middle"
fontWeight="bold"
fill="#111"
>
{item[1]}
</text>

<text
x={x}
y="242"
fontSize="11"
textAnchor="middle"
fill="#555"
>
{String(item[0]).length>10
?String(item[0]).substring(0,10)+"..."
:String(item[0])}
</text>

</g>

);

})

}

</svg>

</div>

);

})()}

</div> 

</div> 


  {/* =======================================================
   LINHA 3
======================================================= */}

<div
style={{
display:"grid",
gridTemplateColumns:"1fr 1fr",
gap:"22px",
marginBottom:"25px"
}}
>

{/* DESTINO */}

<div
style={{
background:"#fff",
borderRadius:"18px",
padding:"22px",
boxShadow:"0 6px 18px rgba(0,0,0,.08)"
}}
>

<h3
style={{
fontSize:"20px",
fontWeight:"bold",
marginBottom:"20px"
}}
>
Destino das Devoluções
</h3>

{[
{
titulo:"Reenvio",
valor:devolucoesDashboard.filter(
x=>x.destino==="Reenvio"
).length,
cor:"#3b82f6"
},
{
titulo:"Estoque",
valor:devolucoesDashboard.filter(
x=>x.destino==="Estoque"
).length,
cor:"#10b981"
}

].map(item=>(

<div
key={item.titulo}
style={{
marginBottom:"20px"
}}
>

<div
style={{
display:"flex",
justifyContent:"space-between",
marginBottom:"6px"
}}
>

<strong>{item.titulo}</strong>

<span>{item.valor}</span>

</div>

<div
style={{
height:"16px",
background:"#ececec",
borderRadius:"999px"
}}
>

<div
style={{
width:`${
devolucoesDashboard.length===0
?0
:(item.valor/devolucoesDashboard.length)*100
}%`,
height:"100%",
background:item.cor,
borderRadius:"999px",
transition:"0.4s"
}}
/>

</div>

</div>

))

}

</div>

{/* RESULTADO FINAL */}

<div
style={{
background:"#fff",
borderRadius:"18px",
padding:"22px",
boxShadow:"0 6px 18px rgba(0,0,0,.08)"
}}
>

<h3
style={{
fontSize:"20px",
fontWeight:"bold",
marginBottom:"20px"
}}
>
Resultado Final
</h3>

<div
style={{
display:"grid",
gridTemplateColumns:"repeat(3,1fr)",
gap:"18px"
}}
>

{[
{
titulo:"Reenviado",
icone:"🚚",
valor:devolucoesDashboard.filter(
x=>x.status==="Enviado"
).length,
cor:"#2563eb"
},
{
titulo:"Estornado",
icone:"💰",
valor:devolucoesDashboard.filter(
x=>x.status==="Estoque"
).length,
cor:"#10b981"
},
{
titulo:"Cancelado",
icone:"❌",
valor:devolucoesDashboard.filter(
x=>x.status==="Cancelado"
).length,
cor:"#ef4444"
}

].map(card=>(

<div
key={card.titulo}
style={{
background:"#f8fafc",
borderRadius:"14px",
padding:"20px",
textAlign:"center"
}}
>

<div
style={{
fontSize:"34px"
}}
>
{card.icone}
</div>

<div
style={{
fontSize:"28px",
fontWeight:"bold",
marginTop:"8px",
color:card.cor
}}
>
{card.valor}
</div>

<div
style={{
marginTop:"6px",
color:"#666",
fontSize:"14px"
}}
>
{card.titulo}
</div>

</div>

))

}

</div>

</div>

</div>

{/* =======================================================
   LINHA 4
======================================================= */}

<div
style={{
background:"#fff",
borderRadius:"18px",
padding:"24px",
boxShadow:"0 6px 18px rgba(0,0,0,.08)",
marginBottom:"25px"
}}
>

<h3
style={{
fontSize:"20px",
fontWeight:"bold",
marginBottom:"25px"
}}
>
Evolução das Devoluções
</h3>

<div
style={{
display:"flex",
alignItems:"flex-end",
justifyContent:"space-between",
height:"260px",
gap:"14px"
}}
>

{Array.from({length:12}).map((_,mes)=>{

const total=devolucoesDashboard.filter(item=>{

if(!item.data) return false;

const data=new Date(item.data);

return data.getMonth()===mes;

}).length;

const altura=Math.max(total*18,12);

return(

<div
key={mes}
style={{
flex:1,
display:"flex",
flexDirection:"column",
alignItems:"center",
justifyContent:"flex-end"
}}
>

<div
style={{
fontWeight:"bold",
marginBottom:"8px",
color:"#555"
}}
>
{total}
</div>

<div
style={{
width:"100%",
height:`${altura}px`,
background:"linear-gradient(to top,#7c3aed,#a855f7)",
borderRadius:"10px 10px 0 0",
transition:"0.4s"
}}
/>

<div
style={{
marginTop:"10px",
fontSize:"12px",
color:"#666"
}}
>

{
["Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"][mes]
}

</div>

</div>

);

})}

</div>
{/* =======================================================
   LINHA 6 - CASOS CRÍTICOS
======================================================= */}

<div
style={{
background:"#fff",
borderRadius:"18px",
padding:"24px",
boxShadow:"0 6px 18px rgba(0,0,0,.08)"
}}
>

<h3
style={{
fontSize:"20px",
fontWeight:"bold",
marginBottom:"20px"
}}
>
Casos Críticos
</h3>

<table
style={{
width:"100%",
borderCollapse:"collapse"
}}
>

<thead>

<tr
style={{
background:"#f3f4f6"
}}
>

<th style={{padding:"14px",textAlign:"left"}}>Pedido</th>
<th style={{padding:"14px",textAlign:"left"}}>Cliente</th>
<th style={{padding:"14px",textAlign:"left"}}>Status</th>
<th style={{padding:"14px",textAlign:"center"}}>Prioridade</th>

</tr>

</thead>

<tbody>

{devolucoesDashboard

.filter(item=>

!["Enviado","Cancelado","Estoque"].includes(item.status)

)

.sort((a,b)=>

(b.contatos || 0)-(a.contatos || 0)

)

.slice(0,10)

.map(item=>{

let prioridade="🟢 Normal";
let cor="#22c55e";

if((item.contatos || 0)>=2){

prioridade="🟡 Atenção";
cor="#f59e0b";

}

if((item.contatos || 0)>=3){

prioridade="🔴 Crítico";
cor="#ef4444";

}

return(

<tr
key={item.id}
style={{
borderBottom:"1px solid #ececec"
}}
>

<td style={{padding:"14px"}}>

<strong>{item.pedido}</strong>

</td>

<td style={{padding:"14px"}}>

{item.cliente}

</td>

<td style={{padding:"14px"}}>

{item.status}

</td>

<td
style={{
padding:"14px",
textAlign:"center",
fontWeight:"bold",
color:cor
}}
>

{prioridade}

</td>

</tr>

);

})}

</tbody>

</table>

</div>

</div>

</>

)

}

{/* ============================
        FORMULÁRIO
============================ */}

{
abaAtiva==="formulario" && (
<>


<div style={cardStyle}>


<h2>

Registrar Devolução

</h2>









<label>

Data

</label>



<input

type="date"

style={inputStyle}

value={data}

onChange={(e)=>

setData(e.target.value)

}

/>









<label>

Pedido

</label>



<input

style={inputStyle}

placeholder="Número do pedido"

value={pedido}

onChange={(e)=>

setPedido(e.target.value)

}

/>









<label>

Cliente

</label>




<input

style={inputStyle}

placeholder="Nome do cliente"

value={cliente}

onChange={(e)=>

setCliente(e.target.value)

}

/>











<label>

Transportadora

</label>




<select

style={inputStyle}

value={transportadora}

onChange={(e)=>

setTransportadora(e.target.value)

}

>


<option value="">

Selecione

</option>




{

(transportadoras || []).map(item=>(



<option

key={item.id}

value={item.nome}

>

{item.nome}

</option>


))



}



</select>



<label>

Motivo da devolução

</label>



<select

style={inputStyle}

value={motivo}

onChange={(e)=>

setMotivo(e.target.value)

}

>


<option value="">

Selecione

</option>





{

(motivos || []).map(item=>(



<option

key={item.id}

value={item.nome}

>

{item.nome}

</option>


))


}



</select>


<label>

Status

</label>



<select

style={inputStyle}

value={status}

onChange={(e)=>

setStatus(e.target.value)

}

>


<option>

Recebido

</option>


<option>

Em análise

</option>


<option>

Aguardando cliente

</option>


<option>

Finalizado

</option>



</select>






<label>

Responsável

</label>




<select

style={inputStyle}

value={responsavel}

onChange={(e)=>

setResponsavel(e.target.value)

}

>


<option value="">

Selecione

</option>



{

(operadores || []).map(item=>(



<option

key={item.id}

value={item.nome}

>

{item.nome}

</option>



))



}



</select>









<label>

Observação

</label>



<textarea

style={{

...inputStyle,

height:"90px"

}}

value={observacao}

onChange={(e)=>

setObservacao(e.target.value)

}

placeholder="Informações adicionais"

/>
</div>
</>

)}








{/* ============================
        CONTROLE REENVIO
============================ */}



<h3

style={{

marginTop:"15px",

fontWeight:"bold"

}}

>

Controle de Reenvio

</h3>







<select

style={inputStyle}

value={precisaReenvio}

onChange={(e)=>

setPrecisaReenvio(e.target.value)

}

>


<option>

Não

</option>


<option>

Sim

</option>



</select>








{

precisaReenvio==="Sim" && (



<>



<input

style={inputStyle}

placeholder="Novo pedido / reenvio"

value={novoPedido}

onChange={(e)=>

setNovoPedido(e.target.value)

}

/>







<label>

Data do Reenvio

</label>



<input

type="date"

style={inputStyle}

value={dataReenvio}

onChange={(e)=>

setDataReenvio(e.target.value)

}

/>





</>



)



}









<button

style={buttonStyle}

onClick={salvarDevolucao}

>

➕ Registrar Devolução

</button>





</div>









{/* ============================
        LISTAGEM
============================ */}



<div

style={{

marginTop:"35px"

}}

>



<h2

style={{

fontSize:"22px",

fontWeight:"bold",

marginBottom:"15px"

}}

>

Devoluções Registradas

</h2>









<div style={cardStyle}>





{

registrosExibidos.length===0 ? (



<p>

Nenhum registro encontrado.

</p>



)

:

(





<table

style={{

width:"100%",

borderCollapse:"collapse"

}}

>



<thead>


<tr>



<th>

Data

</th>



<th>

Pedido

</th>



<th>

Cliente

</th>



<th>

Status

</th>



<th>

Reenvio

</th>



<th>

Ação

</th>



</tr>


</thead>








<tbody>




{

registrosExibidos.map(item=>(



<tr

key={item.id}

onClick={()=>abrirDevolucao(item)}

style={{
  cursor:"pointer"
}}

>



<td>

{item.data || "-"}

</td>






<td>

{item.pedido || "-"}

</td>







<td>

{item.cliente || "-"}

</td>






<td>

{item.status || "-"}

</td>






<td>

{item.destino === "Reenvio" ? "Sim" : "Não"}

</td>







<td>

<div
style={{

display:"flex",

gap:"8px"

}}
>

{

["Enviado","Cancelado","Estoque"].includes(item.status)

?

(

<button

style={{

background:"#9ca3af",

color:"#fff",

border:"none",

padding:"8px 12px",

borderRadius:"8px",

cursor:"not-allowed"

}}

disabled

>

Finalizado

</button>

)

:

(

<button

style={{

background:"#2563eb",

color:"#fff",

border:"none",

padding:"8px 12px",

borderRadius:"8px",

cursor:"pointer"

}}

onClick={(e)=>{
    e.stopPropagation();
    abrirEdicao(item);
}}

>

Editar

</button>

)

}



<button
  style={{
    background:"#dc2626",
    color:"#fff",
    border:"none",
    padding:"8px 12px",
    borderRadius:"8px",
    cursor:"pointer"
  }}
  onClick={async (e) => {
    e.stopPropagation();

    const confirmar = window.confirm("Excluir este registro?");

    if (confirmar) {
      await removerDevolucao(item.id);
    }
  }}
>
  Excluir
</button>

</div>

</td>




</tr>




))



}




</tbody>





</table>



)



}





</div>





</div>

</>
)

}
{/* ======================================
      PAINEL DE EDIÇÃO
====================================== */}

{

editando && registroSelecionado && (

<div

style={{

position:"fixed",

top:0,

right:0,

width:"500px",

height:"100vh",

background:"#fff",

boxShadow:"-5px 0 20px rgba(0,0,0,.25)",

padding:"25px",

overflowY:"auto",

zIndex:9999

}}

>

<h2>

Editar Caso

</h2>

<hr/>

<br/>

<label>

Pedido

</label>

<input

style={inputStyle}

value={registroSelecionado.pedido}

readOnly

/>

<label>

Cliente

</label>

<input

style={inputStyle}

value={registroSelecionado.cliente}

readOnly

/>

<label>

Transportadora

</label>

<input

style={inputStyle}

value={registroSelecionado.transportadora}

readOnly

/>

<label>

Motivo

</label>

<input

style={inputStyle}

value={registroSelecionado.motivo}

readOnly

 />

<div>

<label>Status</label>

<select

style={inputStyle}

value={editStatus}

disabled={somenteLeitura}

onChange={(e)=>

alterarStatus(e.target.value)

}
>

<option>Recebido</option>

<option>Em contato</option>

<option>Reenviar</option>

<option>Enviado</option>

<option>Cancelado</option>

<option>Para estoque</option>

<option>Estoque</option>

</select>


<div>

<div>
  
<label>
Contatos
</label>

<label>

Decisão Final

</label>


<input

style={inputStyle}

value={editDecisaoFinal}

readOnly

/>
<label>

Observação

</label>

<textarea

style={{

...inputStyle,

height:"90px"

}}

value={editObservacao}

disabled={somenteLeitura}

onChange={(e)=>

setEditObservacao(e.target.value)

}

/>
<p
  style={{
    fontWeight: "bold",
    color: corContato()
  }}
>

{editContatos === 0 && "⚪ Nenhum contato"}

{editContatos === 1 && "🟢 1ª tentativa"}

{editContatos === 2 && "🟡 2ª tentativa"}

{editContatos >= 3 && `🔴 ${editContatos}ª tentativa`}

</p>


<button

onClick={registrarContato}

disabled={somenteLeitura}

>

Registrar contato

</button>


</div>

</div>

<h3>
Histórico
</h3>


{

historicosDevolucao.map((item) => (

  <div
    key={item.id}
    style={{
      borderLeft: "4px solid #7c3aed",
      paddingLeft: "12px",
      marginBottom: "18px",
      paddingBottom: "10px",
      borderBottom: "1px solid #e5e7eb"
    }}
  >

    <div
      style={{
        fontSize: "12px",
        color: "#6b7280",
        marginBottom: "6px"
      }}
    >
      📅 {item.created_at
        ? new Date(item.created_at).toLocaleString("pt-BR")
        : "-"}
    </div>

    <div
      style={{
        fontSize: "12px",
        color: "#6b7280",
        marginBottom: "8px"
      }}
    >
      👤 {item.usuario || "Sistema"}
    </div>

    <strong>
      {item.acao}
    </strong>

    <p
      style={{
        marginTop: "4px"
      }}
    >
      {item.descricao}
    </p>

  </div>

))

}
<button

style={{

...buttonStyle,

background:"#16a34a",

marginTop:"20px",

opacity:somenteLeitura ? .5 : 1

}}

onClick={salvarEdicao}

disabled={salvando || somenteLeitura}

>

{salvando ? "Salvando..." : "Salvar alterações"}

</button>


<button

style={{

...buttonStyle,

background:"#6b7280",

marginTop:"10px"

}}

onClick={fecharEdicao}

>

Fechar

</button>

</div>
        </div>

      )}

        </div>

  );

}


function CardIndicador({

titulo,

valor,

cor

}:{

titulo:string;

valor:number;

cor:string;

}){

return(

<div
style={{

background:"#fff",

borderLeft:`6px solid ${cor}`,

padding:"18px",

borderRadius:"12px",

boxShadow:"0 3px 10px rgba(0,0,0,.08)"

}}
>

<div
style={{
fontSize:"14px",
color:"#666"
}}
>

{titulo}

</div>

<div
style={{
fontSize:"34px",
fontWeight:"bold",
color:cor
}}
>

{valor}

</div>

</div>

);

}